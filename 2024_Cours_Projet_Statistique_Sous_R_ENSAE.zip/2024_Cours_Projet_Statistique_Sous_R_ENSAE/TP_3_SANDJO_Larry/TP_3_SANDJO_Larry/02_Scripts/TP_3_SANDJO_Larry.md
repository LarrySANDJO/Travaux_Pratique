---
fontsize: 12pt
numbersections: true
output:
  html_document: 
    toc_depth: 4
    toc: true
    theme: cosmo
    fig_caption: true
    number_sections: true
    keep_md: true
  pdf_document:
    toc_depth: 4
    number_sections: true
    keep_tex: true
header-includes: 
  - \usepackage{pdfpages}
  - \usepackage{tcolorbox}
  - \usepackage{graphicx}
  - \usepackage{setspace}
---



\includepdf{Page de garde TP3 R.pdf}

\newpage

\setstretch{1}

\renewcommand{\contentsname}{\textcolor{blue}{Table des matières}}

\textcolor{blue}{\tableofcontents}

\newpage

\textcolor{blue}{\listoftables}

\textcolor{blue}{\listoffigures}

\newpage

\textcolor{blue}{\section*{Introduction}\addcontentsline{toc}{section}{Introduction}}

Le TP suivant a pour objectif de présenter les codes et le tracer des graphiques spécifiques à partir de bases de données au format csv nommées respectivement annual-growth-in-gni-per-capita.csv, population-growth-annual.csv et gender-inequality-index.csv.

Il sera question tout au long de celui-ci d'utiliser l'ensemble des notions utiles appréhendées au cours de logiciel R pour pouvoir reproduire les graphiques soumis de la meilleure façon possible.

**NB :**
**Le graphique dynamique peut être vu dans le document HTML. Le document pdf ne contient que le graphe simple.**

\newpage

#### Importation de toutes les libraries utilisées.
\


```r
library(readxl)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(gridExtra)
library(plotly)
```

\newpage

# Premier graphique "annual-growth-in-gni-per-capita.csv"

## Importation de la base de données 


```r
# Librarie nécessaire
# Importation de la base
base_1 <- read.csv("../01_Donnees/annual-growth-in-gni-per-capita.csv", header = TRUE)
```

## Extraction des données de l'Afrique de l'Ouest et ceux du Niger


```r
# J'extrait les données du Niger à l'aide de filter() de dplyr
Niger_data <- base_1 |> 
  filter(Region.Name %in% c("Niger"))
```


```r
# J'extrait les données de l'Afrique de l'Ouest à l'aide de filter() de dplyr
western_africa_data <- base_1 |> 
  filter(Region.Name %in% c("Benin",
  "Burkina Faso",
  "Cabo Verde",
  "Côte d’Ivoire",
  "Gambia",
  "Ghana",
  "Guinea",
  "Guinea-Bissau",
  "Liberia",
  "Mali",
  "Mauritania",
  "Niger",
  "Nigeria",
  "Senegal",
  "Sierra Leone",
  "Togo"))
```

## Regroupement et calcul des moyennes par années


```r
Niger_Gini <- Niger_data |>
  group_by(End.Year) |> 
  summarise(Niger = mean(Value))
```


```r
# À l'aide de la fonction group_by() de dplyr
# je regroupe mes données selon les dates
# Ensuite, à l'aide de summarise, je calcule la valeur moyenne pour chaque année.

western_Gini <- western_africa_data |> 
  group_by(End.Year) |>
  summarise(Western_Africa = mean(Value))
```


```r
# Je fais la même chose pour le monde entier
world_Gini <- base_1 |> 
  group_by(End.Year) |>
  summarise(World = mean(Value, na.rm = TRUE))
```

## Graphique


```r
# Je merge mes dataframe pour faciliter le tracé 
data <- merge(Niger_Gini,
              western_Gini,
              by = "End.Year",
              all = TRUE) |> 
  merge(world_Gini,
        by = "End.Year",
        all = TRUE)
```


```r
# Je créer le graphique
ggplot(data, aes(x = End.Year)) +
  geom_line(aes(y = Niger), 
            size = 1, 
            show.legend = "point",
            color = "#4682B4") +
  geom_point(aes(y = Niger, color = "Niger"),
             size = 2,
             show.legend = TRUE) +
  geom_line(aes(y = Western_Africa), 
            size = 1, 
            show.legend = "point",
            color = "#696969") +
  geom_point(aes(y = Western_Africa, color = "Western Africa"),
             size = 2,
             show.legend = TRUE) +
  geom_line(aes(y = World), 
            size = 1, 
            show.legend = "point",
            color = "gray") +
  geom_point(aes(y = World, color = "World"),
             size = 2,
             show.legend = TRUE) +
  scale_color_manual(values = c("#4682B4", "#696969", "gray")) +
  labs(x = "", 
       y = "", 
       color = "", 
       title = "Figure 1 : Income growth and distribution (Gini Index)") +
  theme_minimal() +
  theme(legend.position = c(0.13, 1.008), # Je met la légende en haut à gauche
        legend.direction = "horizontal",  # Je mets la légende horizontalement 
        legend.key = element_blank(), # je retire l'identifiant de la légende 
        panel.grid.minor = element_blank(), # Je retire la grille par défaut 
        axis.text = element_text(size = 11, color = "black"),
        legend.title = element_text(size = 14),
        plot.title = element_text(colour = "#4682B4", 
                                  face = "italic",
                                  size = 13,
                                  hjust = 0,
                                  vjust = 2.5))+
  scale_x_continuous(limits = c(1960, 2021), 
                     breaks = seq(min(data$End.Year) - 1, 
                                  max(data$End.Year) - 1, 
                                  by = 10)) + # J'ajuste l'axe des abscisses
  scale_y_continuous(limits = c(-20, 10)) + # J'ajuste l'axe des ordonnés
  geom_hline(yintercept = c(-20,
                            -15,
                            -10,
                            -5, 
                            0,
                            5,
                            10),
             linetype = "dashed", # Configuration des lignes horizontales
             color = "gray") +
  geom_vline(xintercept = c(1970, 
                            1980, 
                            1990, 
                            2000, 
                            2010,
                            2020), # Verticales 
             color = "gray") +# J'arrange la grille
  guides(color = guide_legend(override.aes = list(size = 4))) +
  labs(caption = "Source: World Bank") + # La source
  theme(plot.caption = element_text(size = 13, # Je positionne le titre
                                    hjust = 0, 
                                    vjust = 1, 
                                    margin = margin(0, 10, 0, 0)))
```

![](TP_3_SANDJO_Larry_files/figure-html/unnamed-chunk-9-1.png)<!-- -->

\newpage 

# Deuxième graphique "population-growth-annual.csv"

## Importation de la base de données 


```r
# Librarie nécessaire
# Importation de la base
base_2 <- read.csv("../01_Donnees/population-growth-annual.csv", header = TRUE)
```

## Extraction des données de l'Afrique de l'Ouest et ceux du Niger


```r
# J'extrait les données du Niger à l'aide de filter() de dplyr
Niger_data <- base_2 |> 
  filter(Region.Name %in% c("Niger"))
```


```r
# J'extrait les données de l'Afrique de l'Ouest à l'aide de filter() de dplyr
western_africa_data <- base_2 |> 
  filter(Region.Name %in% c("Benin",
  "Burkina Faso",
  "Cabo Verde",
  "Côte d’Ivoire",
  "Gambia",
  "Ghana",
  "Guinea",
  "Guinea-Bissau",
  "Liberia",
  "Mali",
  "Mauritania",
  "Niger",
  "Nigeria",
  "Senegal",
  "Sierra Leone",
  "Togo"))
```

## Regroupement et calcul des moyennes par années 


```r
Niger_growth <- Niger_data |>
  group_by(End.Year) |> 
  summarise(Mean_value = mean(Value, na.rm = TRUE))
```



```r
# À l'aide de la fonction group_by() de dplyr
# je regroupe mes données selon les dates
# Ensuite, à l'aide de summarise, je calcule la valeur moyenne pour chaque année.

western_growth <- western_africa_data |> 
  group_by(End.Year) |>
  summarise(Mean_value = mean(Value, na.rm = TRUE))
```


```r
# Je fais la même chose pour le monde entier
world_growth <- base_2 |> 
  group_by(End.Year) |>
  summarise(Mean_value = mean(Value, na.rm = TRUE))
```


## Graphique


```r
## Je trace le graphe à l'aide de ggplot


# Je crée un data.frame pour plus de simplicité 
data <- data.frame(
  year = Niger_growth$End.Year,
  value = c(Niger_growth$Mean_value, 
            western_growth$Mean_value, 
            world_growth$Mean_value),
  group = rep(
    c("Niger", "Western Africa", "World"), 
    each = 61)
)
```


```r
# Je créer le graphique
ggplot(data, aes(x = year, y = value, color = group)) +
  geom_line(size = 1, show.legend = "point") +
  geom_point(size = 2) +
  labs(x = "", 
       y = "", 
       color = "", 
       title = "Figure 2 : Annual population growth (%)") +
  scale_color_manual(values = c("#4682B4", "#696969", "gray")) +
  theme_minimal() +
  theme(legend.position = c(0.13, 1.008), # Je met la légende en haut à gauche
        legend.direction = "horizontal",  # Je mets la légende horizontalement 
        legend.key = element_blank(), # Je retire l'identifiant de la légende 
        panel.grid.minor = element_blank(), # Je retire la grille par défaut 
        axis.text = element_text(size = 11, color = "black"),
        legend.title = element_text(size = 14),
        plot.title = element_text(colour = "#4682B4", 
                                  face = "italic",
                                  size = 13,
                                  hjust = 0,
                                  vjust = 2.5)) +
  scale_x_continuous(limits = c(1961, 2021), 
                     breaks = seq(min(data$year) - 1, 
                                  max(data$year) - 1, 
                                  by = 10)) + # J'ajuste l'axe des abscisses
  scale_y_continuous(limits = c(0.5, 4)) + # J'ajuste l'axe des ordonnés
  geom_hline(yintercept = c(1, 2, 3, 4), 
             linetype = "dotted", 
             color = "#696969") + # J'arrange la grille
  guides(color = guide_legend(override.aes = list(size = 4))) +
  labs(caption = "Source: World Bank") +
  theme(plot.caption = element_text(size = 13, 
                                    hjust = 0, 
                                    vjust = 1, 
                                    margin = margin(0, 10, 0, 0)))
```

![](TP_3_SANDJO_Larry_files/figure-html/unnamed-chunk-17-1.png)<!-- -->

\newpage

# Troisième graphique "gender-inequality-index.csv"

## Importation de la base de données 


```r
# Librarie nécessaire
# Importation de la base
base_3 <- read.csv("../01_Donnees/gender-inequality-index.csv", header = TRUE)
```

## Extraction des données de l'Afrique de l'Ouest et ceux du Niger


```r
# J'extrait les données du Niger à l'aide de filter() de dplyr
Niger_data <- base_3 |> 
  filter(Region.Name %in% c("Niger"))
```


```r
# J'extrait les données de l'Afrique de l'Ouest à l'aide de filter() de dplyr
western_africa_data <- base_3 |> 
  filter(Region.Name %in% c("Benin",
  "Burkina Faso",
  "Cabo Verde",
  "Côte d’Ivoire",
  "Gambia",
  "Ghana",
  "Guinea",
  "Guinea-Bissau",
  "Liberia",
  "Mali",
  "Mauritania",
  "Niger",
  "Nigeria",
  "Senegal",
  "Sierra Leone",
  "Togo"))
```

## Regroupement et calcul des moyennes par années 


```r
Niger_gender <- Niger_data |>
  group_by(End.Year) |> 
  summarise(Niger = mean(Value, na.rm = TRUE))
```



```r
# À l'aide de la fonction group_by() de dplyr
# je regroupe mes données selon les dates
# Ensuite, à l'aide de summarise, je calcule la valeur moyenne pour chaque année.

western_gender <- western_africa_data |> 
  group_by(End.Year) |>
  summarise(Western_Africa = mean(Value, na.rm = TRUE))
```


```r
# Je fais la même chose pour le monde entier
world_gender <- base_3 |> 
  group_by(End.Year) |>
  summarise(World = mean(Value, na.rm = TRUE))
```


## Graphique


```r
# Je merge mes dataframe pour faciliter le tracé 
data <- merge(Niger_gender,
              western_gender,
              by = "End.Year") |> 
  merge(world_gender,
        by = "End.Year")
```


```r
# Je créer le graphique
graphe <- ggplot(data, aes(x = End.Year)) +
  geom_line(aes(y = Niger), 
            size = 1, 
            show.legend = "point",
            color = "#4682B4") +
  geom_point(aes(y = Niger, color = "Niger"),
             size = 2,
             show.legend = TRUE) +
  geom_line(aes(y = Western_Africa), 
            size = 1, 
            show.legend = "point",
            color = "#696969") +
  geom_point(aes(y = Western_Africa, color = "Western Africa"),
             size = 2,
             show.legend = TRUE) +
  geom_line(aes(y = World), 
            size = 1, 
            show.legend = "point",
            color = "gray") +
  geom_point(aes(y = World, color = "World"),
             size = 2,
             show.legend = TRUE) +
  scale_color_manual(values = c("#4682B4", "#696969", "gray")) +
  labs(x = "", 
       y = "", 
       color = "", 
       title = "Figure 3 : Gender inequality index") +
  theme_minimal() +
  theme(legend.position = c(0.13, 1.008), # Je met la légende en haut à gauche
        legend.direction = "horizontal",  # Je mets la légende horizontalement 
        legend.key = element_blank(), # je retire l'identifiant de la légende 
        panel.grid.minor = element_blank(), # Je retire la grille par défaut 
        axis.text = element_text(size = 11, color = "black"),
        legend.title = element_text(size = 14),
        plot.title = element_text(colour = "#4682B4", 
                                  face = "italic",
                                  size = 13,
                                  hjust = 0,
                                  vjust = 2.5))+
  scale_x_continuous(limits = c(1990, 2021), 
                     breaks = seq(min(data$End.Year), 
                                  max(data$End.Year), 
                                  by = 5)) + # J'ajuste l'axe des abscisses
  scale_y_continuous(limits = c(0.1, 0.8)) + # J'ajuste l'axe des ordonnés
  geom_hline(yintercept = c(0.2, 0.4, 0.6, 0.8), 
             linetype = "dashed", 
             color = "gray") +
  geom_vline(xintercept = c(1990, 
                            1995, 
                            2000, 
                            2005, 
                            2010, 
                            2015, 
                            2020), 
             color = "gray") +# J'arrange la grille
  guides(color = guide_legend(override.aes = list(size = 4))) +
  labs(caption = "Source: UNDP") +
  theme(plot.caption = element_text(size = 13, # Je positionne le titre
                                    hjust = 0, 
                                    vjust = 1, 
                                    margin = margin(0, 10, 0, 0)))


# Je rend mon graphe dynamique grâce à ggplotly de plotly
# J'utilise tooltip pour que le rendu ressemble à celui demandé 
ggplotly(graphe, tooltip = c("y"), dynamicTicks = TRUE) |>
  layout(legend = list(x = 0.13, y = 1.008),
         traceorder = "normal",
         font = list(size = 14)) |>
  layout(legend = list(orientation = "h"))
```

```{=html}
<div class="plotly html-widget html-fill-item" id="htmlwidget-385fe62ce301604b7727" style="width:864px;height:576px;"></div>
<script type="application/json" data-for="htmlwidget-385fe62ce301604b7727">{"x":{"data":[{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.79600000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79700000000000004,0.79600000000000004,0.79500000000000004,0.79400000000000004,0.79300000000000004,0.79200000000000004,0.79000000000000004,0.78800000000000003,0.78700000000000003,0.69899999999999995,0.69699999999999995,0.69499999999999995,0.69299999999999995,0.68999999999999995,0.69699999999999995,0.69399999999999995,0.67400000000000004,0.66900000000000004,0.66400000000000003,0.66000000000000003,0.65600000000000003,0.64800000000000002,0.63700000000000001,0.63500000000000001,0.63200000000000001,0.63100000000000001,0.61099999999999999],"text":["Niger: 0.796","Niger: 0.795","Niger: 0.795","Niger: 0.795","Niger: 0.795","Niger: 0.797","Niger: 0.796","Niger: 0.795","Niger: 0.794","Niger: 0.793","Niger: 0.792","Niger: 0.790","Niger: 0.788","Niger: 0.787","Niger: 0.699","Niger: 0.697","Niger: 0.695","Niger: 0.693","Niger: 0.690","Niger: 0.697","Niger: 0.694","Niger: 0.674","Niger: 0.669","Niger: 0.664","Niger: 0.660","Niger: 0.656","Niger: 0.648","Niger: 0.637","Niger: 0.635","Niger: 0.632","Niger: 0.631","Niger: 0.611"],"type":"scatter","mode":"lines","line":{"width":3.7795275590551185,"color":"rgba(70,130,180,1)","dash":"solid"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.79600000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79700000000000004,0.79600000000000004,0.79500000000000004,0.79400000000000004,0.79300000000000004,0.79200000000000004,0.79000000000000004,0.78800000000000003,0.78700000000000003,0.69899999999999995,0.69699999999999995,0.69499999999999995,0.69299999999999995,0.68999999999999995,0.69699999999999995,0.69399999999999995,0.67400000000000004,0.66900000000000004,0.66400000000000003,0.66000000000000003,0.65600000000000003,0.64800000000000002,0.63700000000000001,0.63500000000000001,0.63200000000000001,0.63100000000000001,0.61099999999999999],"text":["Niger: 0.796","Niger: 0.795","Niger: 0.795","Niger: 0.795","Niger: 0.795","Niger: 0.797","Niger: 0.796","Niger: 0.795","Niger: 0.794","Niger: 0.793","Niger: 0.792","Niger: 0.790","Niger: 0.788","Niger: 0.787","Niger: 0.699","Niger: 0.697","Niger: 0.695","Niger: 0.693","Niger: 0.690","Niger: 0.697","Niger: 0.694","Niger: 0.674","Niger: 0.669","Niger: 0.664","Niger: 0.660","Niger: 0.656","Niger: 0.648","Niger: 0.637","Niger: 0.635","Niger: 0.632","Niger: 0.631","Niger: 0.611"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(70,130,180,1)","opacity":1,"size":7.559055118110237,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(70,130,180,1)"}},"hoveron":"points","name":"Niger","legendgroup":"Niger","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.72030000000000005,0.71850000000000003,0.71720000000000006,0.71609999999999996,0.71450000000000002,0.71289999999999998,0.71150000000000002,0.71020000000000005,0.70440000000000003,0.69999999999999996,0.69169230769230772,0.68830769230769229,0.68300000000000005,0.67314285714285715,0.66642857142857148,0.65973333333333339,0.6512,0.64626666666666666,0.64573333333333338,0.64473333333333338,0.64353333333333329,0.64213333333333333,0.63660000000000005,0.6313333333333333,0.62706666666666666,0.61231250000000004,0.60881249999999998,0.60312500000000002,0.60143749999999996,0.59887500000000005,0.59837499999999999,0.59375],"text":["Western_Africa: 0.7203000","Western_Africa: 0.7185000","Western_Africa: 0.7172000","Western_Africa: 0.7161000","Western_Africa: 0.7145000","Western_Africa: 0.7129000","Western_Africa: 0.7115000","Western_Africa: 0.7102000","Western_Africa: 0.7044000","Western_Africa: 0.7000000","Western_Africa: 0.6916923","Western_Africa: 0.6883077","Western_Africa: 0.6830000","Western_Africa: 0.6731429","Western_Africa: 0.6664286","Western_Africa: 0.6597333","Western_Africa: 0.6512000","Western_Africa: 0.6462667","Western_Africa: 0.6457333","Western_Africa: 0.6447333","Western_Africa: 0.6435333","Western_Africa: 0.6421333","Western_Africa: 0.6366000","Western_Africa: 0.6313333","Western_Africa: 0.6270667","Western_Africa: 0.6123125","Western_Africa: 0.6088125","Western_Africa: 0.6031250","Western_Africa: 0.6014375","Western_Africa: 0.5988750","Western_Africa: 0.5983750","Western_Africa: 0.5937500"],"type":"scatter","mode":"lines","line":{"width":3.7795275590551185,"color":"rgba(105,105,105,1)","dash":"solid"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.72030000000000005,0.71850000000000003,0.71720000000000006,0.71609999999999996,0.71450000000000002,0.71289999999999998,0.71150000000000002,0.71020000000000005,0.70440000000000003,0.69999999999999996,0.69169230769230772,0.68830769230769229,0.68300000000000005,0.67314285714285715,0.66642857142857148,0.65973333333333339,0.6512,0.64626666666666666,0.64573333333333338,0.64473333333333338,0.64353333333333329,0.64213333333333333,0.63660000000000005,0.6313333333333333,0.62706666666666666,0.61231250000000004,0.60881249999999998,0.60312500000000002,0.60143749999999996,0.59887500000000005,0.59837499999999999,0.59375],"text":["Western_Africa: 0.7203000","Western_Africa: 0.7185000","Western_Africa: 0.7172000","Western_Africa: 0.7161000","Western_Africa: 0.7145000","Western_Africa: 0.7129000","Western_Africa: 0.7115000","Western_Africa: 0.7102000","Western_Africa: 0.7044000","Western_Africa: 0.7000000","Western_Africa: 0.6916923","Western_Africa: 0.6883077","Western_Africa: 0.6830000","Western_Africa: 0.6731429","Western_Africa: 0.6664286","Western_Africa: 0.6597333","Western_Africa: 0.6512000","Western_Africa: 0.6462667","Western_Africa: 0.6457333","Western_Africa: 0.6447333","Western_Africa: 0.6435333","Western_Africa: 0.6421333","Western_Africa: 0.6366000","Western_Africa: 0.6313333","Western_Africa: 0.6270667","Western_Africa: 0.6123125","Western_Africa: 0.6088125","Western_Africa: 0.6031250","Western_Africa: 0.6014375","Western_Africa: 0.5988750","Western_Africa: 0.5983750","Western_Africa: 0.5937500"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(105,105,105,1)","opacity":1,"size":7.559055118110237,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(105,105,105,1)"}},"hoveron":"points","name":"Western Africa","legendgroup":"Western Africa","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.48757812499999997,0.48507812499999997,0.48176562499999998,0.47848437500000002,0.47474218750000002,0.4706153846153846,0.4656153846153846,0.4605153846153846,0.45937499999999998,0.45480851063829786,0.44871527777777775,0.44426845637583895,0.43871333333333334,0.43379084967320264,0.42841025641025643,0.42323899371069185,0.41443827160493829,0.40620858895705519,0.4039325153374233,0.39999386503067486,0.39871515151515152,0.39391017964071856,0.38750299401197608,0.37971856287425149,0.37722754491017962,0.37178571428571427,0.3652130177514793,0.35588823529411767,0.35178235294117649,0.34691764705882355,0.34415882352941179,0.34437647058823528],"text":["World: 0.4875781","World: 0.4850781","World: 0.4817656","World: 0.4784844","World: 0.4747422","World: 0.4706154","World: 0.4656154","World: 0.4605154","World: 0.4593750","World: 0.4548085","World: 0.4487153","World: 0.4442685","World: 0.4387133","World: 0.4337908","World: 0.4284103","World: 0.4232390","World: 0.4144383","World: 0.4062086","World: 0.4039325","World: 0.3999939","World: 0.3987152","World: 0.3939102","World: 0.3875030","World: 0.3797186","World: 0.3772275","World: 0.3717857","World: 0.3652130","World: 0.3558882","World: 0.3517824","World: 0.3469176","World: 0.3441588","World: 0.3443765"],"type":"scatter","mode":"lines","line":{"width":3.7795275590551185,"color":"rgba(190,190,190,1)","dash":"solid"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.48757812499999997,0.48507812499999997,0.48176562499999998,0.47848437500000002,0.47474218750000002,0.4706153846153846,0.4656153846153846,0.4605153846153846,0.45937499999999998,0.45480851063829786,0.44871527777777775,0.44426845637583895,0.43871333333333334,0.43379084967320264,0.42841025641025643,0.42323899371069185,0.41443827160493829,0.40620858895705519,0.4039325153374233,0.39999386503067486,0.39871515151515152,0.39391017964071856,0.38750299401197608,0.37971856287425149,0.37722754491017962,0.37178571428571427,0.3652130177514793,0.35588823529411767,0.35178235294117649,0.34691764705882355,0.34415882352941179,0.34437647058823528],"text":["World: 0.4875781","World: 0.4850781","World: 0.4817656","World: 0.4784844","World: 0.4747422","World: 0.4706154","World: 0.4656154","World: 0.4605154","World: 0.4593750","World: 0.4548085","World: 0.4487153","World: 0.4442685","World: 0.4387133","World: 0.4337908","World: 0.4284103","World: 0.4232390","World: 0.4144383","World: 0.4062086","World: 0.4039325","World: 0.3999939","World: 0.3987152","World: 0.3939102","World: 0.3875030","World: 0.3797186","World: 0.3772275","World: 0.3717857","World: 0.3652130","World: 0.3558882","World: 0.3517824","World: 0.3469176","World: 0.3441588","World: 0.3443765"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(190,190,190,1)","opacity":1,"size":7.559055118110237,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(190,190,190,1)"}},"hoveron":"points","name":"World","legendgroup":"World","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1988.45,2022.55,null,1988.45,2022.55,null,1988.45,2022.55,null,1988.45,2022.55],"y":[0.20000000000000001,0.20000000000000001,null,0.40000000000000002,0.40000000000000002,null,0.59999999999999998,0.59999999999999998,null,0.80000000000000004,0.80000000000000004],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(190,190,190,1)","dash":"dash"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1990,null,1995,1995,null,2000,2000,null,2005,2005,null,2010,2010,null,2015,2015,null,2020,2020],"y":[0.065000000000000002,0.83500000000000008,null,0.065000000000000002,0.83500000000000008,null,0.065000000000000002,0.83500000000000008,null,0.065000000000000002,0.83500000000000008,null,0.065000000000000002,0.83500000000000008,null,0.065000000000000002,0.83500000000000008,null,0.065000000000000002,0.83500000000000008],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(190,190,190,1)","dash":"solid"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null}],"layout":{"margin":{"t":44.227480282274811,"r":7.3059360730593621,"b":29.223744292237448,"l":32.876712328767127},"font":{"color":"rgba(0,0,0,1)","family":"","size":14},"title":{"text":"<i> Figure 3 : Gender inequality index <\/i>","font":{"color":"rgba(70,130,180,1)","family":"","size":17.268576172685766},"x":0,"xref":"paper"},"xaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":true,"range":[1988.45,2022.55],"tickmode":"auto","ticktext":["1990","1995","2000","2005","2010","2015","2020"],"tickvals":[1990,1995,2000,2005,2010,2015,2020],"categoryorder":"array","categoryarray":["1990","1995","2000","2005","2010","2015","2020"],"nticks":null,"ticks":"","tickcolor":null,"ticklen":3.6529680365296811,"tickwidth":0,"showticklabels":true,"tickfont":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"tickangle":-0,"showline":false,"linecolor":null,"linewidth":0,"showgrid":true,"gridcolor":"rgba(235,235,235,1)","gridwidth":0.66417600664176002,"zeroline":false,"anchor":"y","title":{"text":"","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724}},"hoverformat":".2f"},"yaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":true,"range":[0.065000000000000002,0.83500000000000008],"tickmode":"auto","ticktext":["0.2","0.4","0.6","0.8"],"tickvals":[0.20000000000000001,0.40000000000000002,0.60000000000000009,0.80000000000000004],"categoryorder":"array","categoryarray":["0.2","0.4","0.6","0.8"],"nticks":null,"ticks":"","tickcolor":null,"ticklen":3.6529680365296811,"tickwidth":0,"showticklabels":true,"tickfont":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"tickangle":-0,"showline":false,"linecolor":null,"linewidth":0,"showgrid":true,"gridcolor":"rgba(235,235,235,1)","gridwidth":0.66417600664176002,"zeroline":false,"anchor":"x","title":{"text":"","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724}},"hoverformat":".2f"},"shapes":[{"type":"rect","fillcolor":null,"line":{"color":null,"width":0,"linetype":[]},"yref":"paper","xref":"paper","x0":0,"x1":1,"y0":0,"y1":1}],"showlegend":true,"legend":{"bgcolor":null,"bordercolor":null,"borderwidth":0,"font":{"color":"rgba(0,0,0,1)","family":"","size":11.68949771689498},"title":{"text":"","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969286}},"x":0.13,"y":1.008,"orientation":"h"},"hovermode":"closest","barmode":"relative","traceorder":"normal"},"config":{"doubleClick":"reset","modeBarButtonsToAdd":["hoverclosest","hovercompare"],"showSendToCloud":false},"source":"A","attrs":{"47182e8a1a16":{"x":{},"y":{},"type":"scatter"},"47186b6876c2":{"x":{},"y":{},"colour":{}},"471865337d16":{"x":{},"y":{}},"4718db6d2c":{"x":{},"y":{},"colour":{}},"4718c382277":{"x":{},"y":{}},"471842852331":{"x":{},"y":{},"colour":{}},"4718431a5047":{"yintercept":{}},"47189f4181":{"xintercept":{}}},"cur_data":"47182e8a1a16","visdat":{"47182e8a1a16":["function (y) ","x"],"47186b6876c2":["function (y) ","x"],"471865337d16":["function (y) ","x"],"4718db6d2c":["function (y) ","x"],"4718c382277":["function (y) ","x"],"471842852331":["function (y) ","x"],"4718431a5047":["function (y) ","x"],"47189f4181":["function (y) ","x"]},"highlight":{"on":"plotly_click","persistent":false,"dynamic":false,"selectize":false,"opacityDim":0.20000000000000001,"selected":{"opacity":1},"debounce":0},"shinyEvents":["plotly_hover","plotly_click","plotly_selected","plotly_relayout","plotly_brushed","plotly_brushing","plotly_clickannotation","plotly_doubleclick","plotly_deselect","plotly_afterplot","plotly_sunburstclick"],"base_url":"https://plot.ly"},"evals":[],"jsHooks":[]}</script>
```

\newpage

\textcolor{blue}{\section*{Conclusion}\addcontentsline{toc}{section}{Conclusion}}

Le TP qui nous a été soumis avait pour but de nous amener à utiliser les notions relatives au logiciel R pour pouvoir reproduire des graphiques présentés à l'aide de bases fournies. 

Suite à de nombreuses recherches, nous avons tracé les graphes demandés principalement à l'aide des libraries dplyr, ggplot2 et plotly.
Nous avons aussi découvert de nombreuses fonctionnalités de ces libraries. 











